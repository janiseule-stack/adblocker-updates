// Hinweis in der Seite (ISOLATED), läuft vor bruecke.js. Das Innere liegt in einem geschlossenen
// Shadow-DOM, die Seite kann es nicht lesen. Über die oberste Ebene bleibt es auch im Vollbild sichtbar.
(() => {
  const STIL = `
    :host { all: initial; position: fixed; inset: auto 16px 16px auto; margin: 0; padding: 0; border: 0; background: none; overflow: visible; }
    .kasten { display: flex; align-items: center; gap: 12px; padding: 8px 12px; background: #0a0f0a; color: #9df59d;
      border: 1px solid #2c5a2c; font: 13px/1.4 "Cascadia Code", Consolas, monospace; }
    button { padding: 0; border: 0; background: none; color: #c9ffc9; font: inherit; font-weight: 700; cursor: pointer; }
    button:focus-visible { outline: 2px solid #9df59d; outline-offset: 2px; }`;

  let offen = null;

  globalThis.adblockerHinweis = ({ text, knopf, beiKlick, dauer = 3000 }) => {
    offen?.remove();
    const host = document.createElement('div');
    host.setAttribute('data-adblocker-hinweis', '');
    host.setAttribute('aria-label', text);
    host.setAttribute('role', 'status');
    host.popover = 'manual';
    const inneres = host.attachShadow({ mode: 'closed' });
    const stil = document.createElement('style');
    stil.textContent = STIL;
    const kasten = document.createElement('div');
    kasten.className = 'kasten';
    const zeile = document.createElement('span');
    zeile.textContent = text;
    kasten.append(zeile);
    if (knopf) {
      const element = document.createElement('button');
      element.type = 'button';
      element.textContent = knopf;
      element.addEventListener('click', (ereignis) => {
        if (!ereignis.isTrusted) return;
        host.remove();
        beiKlick?.();
      });
      kasten.append(element);
    }
    inneres.append(stil, kasten);
    document.documentElement.append(host);
    host.showPopover();
    offen = host;
    setTimeout(() => host.remove(), dauer);
  };
})();
