// Schutz (MAIN-Welt): Pop-ups, Pausen-Erkennung, Klickflächen, Weiterleitungen und gefälschte Fenster.
// Läuft als klassisches Skript vor jedem Skript der Seite und hinterlässt keine Globals. Der Schutz ist von
// Anfang an aktiv, damit nichts vor der Antwort der Brücke durchrutscht.
(() => {
  // Grundfunktionen jetzt festhalten: Die Seite könnte sie später ersetzen und den Schutz damit aushebeln.
  const nurAufruf = Function.prototype.call.bind(Function.prototype.bind, Function.prototype.call);
  const lesen = JSON.parse;
  const jetzt = Date.now.bind(Date);
  const Adresse = URL;
  const endetMit = nurAufruf(String.prototype.endsWith);
  const beginntMit = nurAufruf(String.prototype.startsWith);
  const stilVon = window.getComputedStyle.bind(window);
  const testen = nurAufruf(RegExp.prototype.test);
  const anhalten = nurAufruf(Event.prototype.stopImmediatePropagation);
  const verhindern = nurAufruf(Event.prototype.preventDefault);

  // Anmelde- und Zahlungsdienste. Die gleiche Liste steht in lib/logik.js (ein Test prüft das).
  const DIENSTE = ['accounts.google.com', 'appleid.apple.com', 'login.live.com', 'login.microsoftonline.com', 'facebook.com', 'discord.com', 'github.com', 'twitch.tv', 'steamcommunity.com', 'auth.riotgames.com', 'paypal.com', 'klarna.com', 'stripe.com', 'mollie.com', 'x.com', 'twitter.com', 'linkedin.com', 'login.yahoo.com', 'amazon.com', 'amazon.de', 'auth0.com', 'okta.com', 'adyen.com'];

  let aktiv = true;
  let streng = false;
  let einstellungenDa = false;
  let planeFensterPruefung = () => {};
  // Bis zur Antwort der Brücke die eigene Domain, damit eigene Fenster nicht als fremd gelten.
  let seite = location.hostname.split('.').slice(-2).join('.');

  // Der Schlüssel geht nur an die Brücke. Dieser Empfänger steht als erster auf window und hält die echte
  // Meldung an, die Seite sieht weder sie noch den Schlüssel. Eine Fälschung ohne Schlüssel zählt nicht.
  const schluessel = Array.from(crypto.getRandomValues(new Uint32Array(4))).join('-');

  function nimmEinstellungen(ereignis) {
    let daten;
    try {
      daten = lesen(String(ereignis.detail));
    } catch {
      return;
    }
    if (!daten || daten.schluessel !== schluessel) return;
    anhalten(ereignis);
    if (einstellungenDa) return;
    aktiv = daten.modus !== 'aus';
    streng = daten.modus === 'streng';
    if (typeof daten.seite === 'string' && daten.seite) seite = daten.seite;
    einstellungenDa = true;
    planeFensterPruefung();
  }
  window.addEventListener('__adblocker_schutz', nimmEinstellungen, true);
  document.dispatchEvent(new CustomEvent('__adblocker_anfrage', { detail: schluessel }));

  // Hochstufen während die Seite offen ist. Ohne Schlüssel, weil es den Schutz nur verschärft.
  document.addEventListener('__adblocker_modus', () => {
    if (aktiv) streng = true;
  });

  function meldeAnzeichen() {
    document.dispatchEvent(new CustomEvent('__adblocker_anzeichen'));
  }

  // Die Brücke bietet an, das Fenster einmal zu öffnen. Eine leere Adresse lässt sich nicht nachholen.
  function meldeBlockiert(url) {
    if (url === undefined || url === null || String(url).trim() === '') return;
    try {
      document.dispatchEvent(new CustomEvent('__adblocker_blockiert', { detail: new Adresse(String(url), location.href).href }));
    } catch {
      // Keine gültige Adresse, nichts anzubieten.
    }
  }

  function inListe(host, liste) {
    for (let i = 0; i < liste.length; i++) {
      if (host === liste[i] || endetMit(host, '.' + liste[i])) return true;
    }
    return false;
  }

  function gleicheSeite(host) {
    return host === seite || endetMit(host, '.' + seite);
  }

  function hostVon(url) {
    const text = String(url ?? '');
    return new Adresse(beginntMit(text.toLowerCase(), 'blob:') ? text.slice(5) : text, location.href).hostname;
  }

  function fremdesZiel(url) {
    if (url === undefined || url === null || String(url).trim() === '') return true;
    try {
      return !gleicheSeite(hostVon(url));
    } catch {
      return true;
    }
  }

  // Ein Dienst darf aus seinem eigenen Rahmen auch erst ein leeres Fenster öffnen.
  function erlaubterDienst(url) {
    if (inListe(location.hostname, DIENSTE)) return true;
    try {
      return inListe(hostVon(url), DIENSTE);
    } catch {
      return false;
    }
  }

  // Letzte echte Bedienung: Knopf oder Link, oder eine freie Fläche. Maus und Tastatur zählen.
  const FREIER_KLICK_GILT_MS = 2000;
  // Zwischen Knopf und Fenster kann eine Abfrage liegen, etwa an der Kasse.
  const BEDIENUNG_GILT_MS = 5000;
  const BEDIENUNG = 'a[href], button, input, select, textarea, label, summary, [role="button"], [role="link"]';
  let freierKlick = 0;
  let bedienKlick = 0;
  let linkHost = '';

  function istBedienung(element) {
    if (!(element instanceof Element)) return false;
    if (element.closest(BEDIENUNG)) return true;
    // Anklickbare Karten ohne Knopf zeigen die Hand. Über mehr als die halbe Fläche ist es eher eine Klickfläche.
    const rect = element.getBoundingClientRect();
    return stilVon(element).cursor === 'pointer' && rect.width * rect.height <= (innerWidth * innerHeight) / 2;
  }

  function merkeBedienung(pfad) {
    let bedienung = false;
    let link = null;
    for (let i = 0; i < pfad.length; i++) {
      const element = pfad[i];
      if (!(element instanceof Element)) continue;
      if (i === 0 && istBedienung(element)) bedienung = true;
      if (element.matches(BEDIENUNG)) bedienung = true;
      if (!link && element.matches('a[href]')) link = element;
    }
    freierKlick = bedienung ? 0 : jetzt();
    bedienKlick = bedienung ? jetzt() : 0;
    linkHost = '';
    if (link) {
      try {
        linkHost = hostVon(link.href);
      } catch {
        // Keine gültige Adresse, zählt als Knopf.
      }
    }
  }

  window.addEventListener(
    'pointerdown',
    (ereignis) => {
      if (ereignis.isTrusted) merkeBedienung(ereignis.composedPath());
    },
    true,
  );
  window.addEventListener(
    'keydown',
    (ereignis) => {
      if (ereignis.isTrusted && (ereignis.key === 'Enter' || ereignis.key === ' ') && document.activeElement) {
        merkeBedienung(ereignis.composedPath());
      }
    },
    true,
  );

  // window.open, für dieses Fenster und für jeden Rahmen derselben Herkunft (siehe unten).
  const eigeneOpen = new WeakSet();
  function machOpen(originalOpen) {
    const neu = {
      open(...argumente) {
        if (!aktiv) return Reflect.apply(originalOpen, this, argumente);
        // Diese Ziele sind Weiterleitungen und keine Fenster, darüber wacht der Teil für Weiterleitungen.
        const ziel = String(argumente[1] ?? '').toLowerCase();
        if (ziel === '_self' || ziel === '_top' || ziel === '_parent') return Reflect.apply(originalOpen, this, argumente);
        if (!fremdesZiel(argumente[0]) || erlaubterDienst(argumente[0])) return Reflect.apply(originalOpen, this, argumente);
        const nachBedienung = jetzt() - bedienKlick <= BEDIENUNG_GILT_MS && gleicheSeite(location.hostname);
        // Ein echter Link, der sich per Skript selbst öffnet, ist ein normaler Link-Klick.
        let selbeAdresse = false;
        try {
          selbeAdresse = linkHost !== '' && hostVon(argumente[0]) === linkHost;
        } catch {
          // Keine gültige Adresse.
        }
        if (nachBedienung && selbeAdresse && !streng) return Reflect.apply(originalOpen, this, argumente);
        // Nach einem Knopf-Klick in der Seite selbst kann es gewollt sein, das ist kein Anzeichen.
        if (nachBedienung) meldeBlockiert(argumente[0]);
        else meldeAnzeichen();
        return null;
      },
    }.open;
    eigeneOpen.add(neu);
    return neu;
  }
  window.open = machOpen(window.open);

  // Rahmen derselben Herkunft, etwa mit src="javascript:false", bekommen von Chrome keine Erweiterung.
  // Pop-under-Skripte holen sich dort ein ungeschütztes window.open. Darum bekommt jeder solche Rahmen den
  // Schutz, sobald die Seite auf sein Fenster zugreift oder ihn einfügt, auch verschachtelt.
  const eigeneGetter = new WeakSet();
  const RAHMEN_ARTEN = ['HTMLIFrameElement', 'HTMLFrameElement', 'HTMLObjectElement'];
  const originalFensterVon = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, 'contentWindow').get;

  function schuetzeFenster(kind) {
    if (!kind || kind === window) return;
    try {
      // Bei fremder Herkunft wirft schon das Lesen, dort läuft die Erweiterung ohnehin selbst.
      const open = kind.open;
      if (!eigeneOpen.has(open)) kind.open = machOpen(open);
      haengeRahmenEin(kind);
    } catch {
      // Fremde Herkunft oder schon geschlossen.
    }
  }

  function ersetzeGetter(prototyp, name, nachher) {
    const beschreibung = prototyp && Object.getOwnPropertyDescriptor(prototyp, name);
    if (!beschreibung?.get || eigeneGetter.has(beschreibung.get)) return;
    const original = beschreibung.get;
    const neu = {
      get [name]() {
        const wert = Reflect.apply(original, this, []);
        nachher(wert);
        return wert;
      },
    };
    const getter = Object.getOwnPropertyDescriptor(neu, name).get;
    eigeneGetter.add(getter);
    Object.defineProperty(prototyp, name, { ...beschreibung, get: getter });
  }

  function haengeRahmenEin(fenster) {
    for (const art of RAHMEN_ARTEN) {
      const prototyp = fenster[art]?.prototype;
      ersetzeGetter(prototyp, 'contentWindow', schuetzeFenster);
      ersetzeGetter(prototyp, 'contentDocument', (dokument) => schuetzeFenster(dokument?.defaultView));
    }
    // Auch Rahmen, deren Fenster die Seite nur über window.frames erreicht.
    if (fenster !== window) beobachteRahmen(fenster.document);
  }

  const beobachtet = new WeakSet();
  function schuetzeEingefuegte(knoten) {
    // Kein instanceof: Knoten aus einem Unter-Rahmen stammen aus dessen eigener Welt.
    if (typeof knoten?.querySelectorAll !== 'function') return;
    const rahmen = knoten.matches?.('iframe, frame') ? [knoten] : [];
    rahmen.push(...knoten.querySelectorAll('iframe, frame'));
    for (const r of rahmen) {
      try {
        schuetzeFenster(Reflect.apply(originalFensterVon, r, []));
      } catch {
        // Ein frame-Element aus einem anderen Fenster, dessen Getter passt nicht.
        schuetzeFenster(r.contentWindow);
      }
    }
  }

  function beobachteRahmen(dokument) {
    if (!dokument || beobachtet.has(dokument)) return;
    beobachtet.add(dokument);
    new MutationObserver((aenderungen) => {
      for (const aenderung of aenderungen) aenderung.addedNodes.forEach(schuetzeEingefuegte);
    }).observe(dokument, { childList: true, subtree: true });
  }

  haengeRahmenEin(window);
  beobachteRahmen(document);

  // Pausen-Erkennung: nur im strengen Modus anders als der Browser.
  function ueberschreibe(ziel, name, wert) {
    let besitzer = ziel;
    let beschreibung;
    while (besitzer && !(beschreibung = Object.getOwnPropertyDescriptor(besitzer, name))) {
      besitzer = Object.getPrototypeOf(besitzer);
    }
    if (!beschreibung || !beschreibung.get) return;
    const original = beschreibung.get;
    Object.defineProperty(ziel, name, {
      configurable: true,
      enumerable: beschreibung.enumerable,
      get: { get() { return streng ? wert : Reflect.apply(original, this, []); } }.get,
    });
  }
  ueberschreibe(document, 'hidden', false);
  ueberschreibe(document, 'visibilityState', 'visible');
  ueberschreibe(document, 'webkitHidden', false);
  ueberschreibe(document, 'webkitVisibilityState', 'visible');

  const originalFokus = document.hasFocus;
  document.hasFocus = {
    hasFocus(...argumente) {
      return streng ? true : Reflect.apply(originalFokus, this, argumente);
    },
  }.hasFocus;

  function verschlucke(ereignis) {
    if (streng && (ereignis.target === window || ereignis.target === document)) anhalten(ereignis);
  }
  window.addEventListener('blur', verschlucke, true);
  window.addEventListener('visibilitychange', verschlucke, true);

  // Unsichtbare Klickflächen
  // Was so etwas enthält, kann der Player oder seine Bedienung sein, auch ohne Text.
  const INHALT = 'video, audio, iframe, embed, object, svg, img, button, input';

  function istKlickflaeche(element) {
    if (!(element instanceof Element)) return false;
    if (element.matches(INHALT) || element.querySelector(INHALT)) return false;
    // Ein großer Link mit Text ist ein Link, keine Klickfläche.
    if (element.textContent.trim() !== '') return false;
    const rect = element.getBoundingClientRect();
    const flaeche = Math.max(0, Math.min(rect.right, innerWidth) - Math.max(rect.left, 0)) *
      Math.max(0, Math.min(rect.bottom, innerHeight) - Math.max(rect.top, 0));
    if (flaeche <= (innerWidth * innerHeight) / 2) return false;
    if (element.matches('a[href]')) return fremdesZiel(element.href);
    // Leere Flächen gibt es auch als Hintergrund hinter Dialogen und Menüs. Sie zählen nur im strengen Modus.
    if (!streng) return false;
    const stil = stilVon(element);
    return stil.position === 'fixed' && Number.parseInt(stil.zIndex, 10) >= 1000;
  }

  window.addEventListener(
    'click',
    (ereignis) => {
      if (!aktiv) return;
      for (let e = ereignis.target; e instanceof Element; e = e.parentElement) {
        if (istKlickflaeche(e)) {
          e.remove();
          meldeAnzeichen();
          verhindern(ereignis);
          anhalten(ereignis);
          return;
        }
      }
    },
    true,
  );

  // Gefälschte Install-Fenster: überlagerndes Kästchen mit kurzem Text und Knopf, das zur Installation
  // auffordert und das mit Werbeblocker oder Weiterschauen begründet. Bewusst ohne Produktnamen.
  const INSTALL = /\b(install|installieren|installiere)\b/i;
  const BEZUG = /ad\s*-?block|werbeblock|sicher\w*\s+modus|safe\s+mode|wiedergabe|continue\s+watching|weiterschauen|freischalten|freizuschalten/i;
  const MAX_FENSTER_TEXT = 400;
  const MIN_FENSTER_ANTEIL = 0.01;

  function passtText(text) {
    return testen(INSTALL, text) && testen(BEZUG, text);
  }

  function istFalschesFenster(element) {
    const text = element.textContent.trim();
    if (text.length > MAX_FENSTER_TEXT || !passtText(text)) return false;
    if (!element.querySelector('button, a, [role="button"]')) return false;
    const stil = stilVon(element);
    if (stil.position !== 'fixed' && stil.position !== 'absolute') return false;
    if (stil.visibility === 'hidden' || stil.display === 'none') return false;
    const rect = element.getBoundingClientRect();
    return rect.width * rect.height >= innerWidth * innerHeight * MIN_FENSTER_ANTEIL;
  }

  function entferneFenster(element) {
    meldeAnzeichen();
    element.remove();
    // Ein Rahmen ohne eigene Adresse besteht nur aus diesem Fenster. Kurz warten, damit die Meldung noch rausgeht.
    if (location.protocol === 'about:' && window.frameElement) {
      const rahmen = window.frameElement;
      rahmen.style.display = 'none';
      setTimeout(() => rahmen.remove(), 100);
    }
  }

  const FENSTER_AUSWAHL = 'div, section, aside, dialog, form';

  function pruefeTeil(wurzel) {
    if (!passtText(wurzel.textContent)) return;
    // In Dokument-Reihenfolge trifft zuerst das äußerste passende Kästchen.
    const kaestchen = wurzel.matches(FENSTER_AUSWAHL) ? [wurzel, ...wurzel.querySelectorAll(FENSTER_AUSWAHL)] : wurzel.querySelectorAll(FENSTER_AUSWAHL);
    for (const element of kaestchen) {
      if (element.isConnected && istFalschesFenster(element)) entferneFenster(element);
    }
  }

  // Beim ersten Mal die ganze Seite, danach nur, was neu dazugekommen ist.
  const FENSTER_PRUEFEN_MS = 500;
  let fensterUhr = null;
  let ganzPruefen = true;
  let neueTeile = new Set();

  function pruefeFenster() {
    if (!aktiv || !einstellungenDa || !document.body) return;
    const teile = ganzPruefen ? [document.body] : [...neueTeile];
    ganzPruefen = false;
    neueTeile = new Set();
    for (const teil of teile) {
      if (teil.isConnected) pruefeTeil(teil);
    }
  }

  planeFensterPruefung = () => {
    fensterUhr ??= setTimeout(() => {
      fensterUhr = null;
      pruefeFenster();
    }, FENSTER_PRUEFEN_MS);
  };
  new MutationObserver((aenderungen) => {
    for (const aenderung of aenderungen) {
      for (const knoten of aenderung.addedNodes) {
        const element = knoten instanceof Element ? knoten : knoten.parentElement;
        if (element) neueTeile.add(element);
      }
    }
    planeFensterPruefung();
  }).observe(document, { childList: true, subtree: true });
  if (einstellungenDa) planeFensterPruefung();

  // Weiterleitung im selben Tab: Klick auf eine freie Fläche, und ein Skript schickt die Seite woandershin.
  // Echte Links und Knöpfe bleiben frei, ebenso Weiterleitungen beim Laden der Seite.
  if (window.top === window && window.navigation) {
    window.navigation.addEventListener('navigate', (ereignis) => {
      if (!aktiv || !ereignis.cancelable || ereignis.userInitiated || ereignis.formData) return;
      if (ereignis.navigationType === 'traverse' || ereignis.navigationType === 'reload') return;
      if (jetzt() - freierKlick > FREIER_KLICK_GILT_MS) return;
      if (fremdesZiel(ereignis.destination.url) && !erlaubterDienst(ereignis.destination.url)) {
        verhindern(ereignis);
        meldeAnzeichen();
      }
    });
  }
})();
