// YouTube (MAIN-Welt): entfernt Werbedaten aus JSON-Antworten, überspringt Werbung im Player
// und räumt den Werbeblocker-Hinweis weg. Klassisches Skript ohne Globals.
// Anders als schutz.js ist es von Anfang an aktiv, weil die Daten vor den Einstellungen
// eintreffen. Nur die erste Meldung zählt: sagt sie blocker:false, bleibt alles aus.
(() => {
  const WERBE_SCHLUESSEL = ['adPlacements', 'adSlots', 'playerAds', 'adBreakHeartbeatParams'];
  const MAX_TIEFE = 3;
  let aktiv = true;

  function nimmEinstellungen(ereignis) {
    document.removeEventListener('__adblocker_einstellungen', nimmEinstellungen);
    try {
      const daten = JSON.parse(String(ereignis.detail));
      if (daten && daten.blocker === false) {
        aktiv = false;
        document.documentElement?.setAttribute('data-adblocker-aus', '');
      }
    } catch {
      // Unlesbare Meldung: Blocker bleibt an.
    }
  }
  document.addEventListener('__adblocker_einstellungen', nimmEinstellungen);
  document.dispatchEvent(new CustomEvent('__adblocker_anfrage'));

  function einfach(wert) {
    if (Array.isArray(wert)) return true;
    if (wert === null || typeof wert !== 'object') return false;
    const proto = Object.getPrototypeOf(wert);
    return proto === Object.prototype || proto === null;
  }

  function saeubere(wert, tiefe = 0) {
    if (!aktiv || !einfach(wert)) return wert;
    if (!Array.isArray(wert)) {
      for (const schluessel of WERBE_SCHLUESSEL) delete wert[schluessel];
    }
    if (tiefe < MAX_TIEFE) {
      for (const kind of Object.values(wert)) saeubere(kind, tiefe + 1);
    }
    return wert;
  }

  const originalParse = JSON.parse;
  JSON.parse = {
    parse(...argumente) {
      return saeubere(Reflect.apply(originalParse, this, argumente));
    },
  }.parse;

  const originalJson = Response.prototype.json;
  Response.prototype.json = {
    json(...argumente) {
      return Reflect.apply(originalJson, this, argumente).then((wert) => saeubere(wert));
    },
  }.json;

  let spielerAntwort;
  Object.defineProperty(window, 'ytInitialPlayerResponse', {
    configurable: true,
    enumerable: true,
    get: { get() { return spielerAntwort; } }.get,
    set: { set(wert) { spielerAntwort = saeubere(wert); } }.set,
  });

  // Werbung überspringen und Hinweis entfernen, gebündelt: höchstens einmal je 50 ms.
  let gemerkt = null; // { video, stumm } solange eine Werbung läuft
  let geplant = false;

  // Immer dieselbe Funktion: So hängt sie trotz mehrerer Läufe nur einmal am Video.
  function springeNachMetadaten(ereignis) {
    const video = ereignis.currentTarget;
    const werbung = document.querySelector('#movie_player')?.classList.contains('ad-showing');
    if (aktiv && werbung && Number.isFinite(video.duration)) video.currentTime = video.duration;
  }

  function arbeite() {
    geplant = false;
    if (!aktiv) return;
    const spieler = document.querySelector('#movie_player');
    const video = spieler?.querySelector('video') ?? null;

    if (spieler?.classList.contains('ad-showing')) {
      for (const knopf of spieler.querySelectorAll('.ytp-skip-ad-button, .ytp-ad-skip-button, .ytp-ad-skip-button-modern')) {
        knopf.click();
      }
      if (video) {
        gemerkt ??= { video, stumm: video.muted };
        video.muted = true;
        if (Number.isFinite(video.duration)) video.currentTime = video.duration;
        else video.addEventListener('loadedmetadata', springeNachMetadaten, { once: true });
      }
    } else if (gemerkt) {
      gemerkt.video.muted = gemerkt.stumm;
      gemerkt = null;
    }

    const hinweise = document.querySelectorAll('ytd-enforcement-message-view-model');
    // Der Hintergrund gehört auch zu normalen Dialogen, darum zählt nur der Hinweis selbst.
    if (hinweise.length > 0) {
      for (const hinweis of hinweise) (hinweis.closest('tp-yt-paper-dialog') ?? hinweis).remove();
      for (const hintergrund of document.querySelectorAll('tp-yt-iron-overlay-backdrop')) hintergrund.remove();
      if (video?.paused) {
        try {
          Promise.resolve(video.play()).catch(() => {});
        } catch {
          // Abspielen abgelehnt: egal.
        }
      }
    }
  }

  new MutationObserver(() => {
    if (!aktiv || geplant) return;
    geplant = true;
    setTimeout(arbeite, 50);
  }).observe(document, { subtree: true, childList: true, attributes: true, attributeFilter: ['class'] });
})();
