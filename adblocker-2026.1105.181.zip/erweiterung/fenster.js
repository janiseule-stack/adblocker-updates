// Fenster am Symbol: Schalter und Modus für die aktuelle Seite. Ein Klick schreibt in den Speicher
// und lädt den Tab neu, ohne Tippen und ohne Bestätigung.
import { hauptDomain, istInListe, mitSchalter, seitenModus, updateVeraltet } from './lib/logik.js';

const blocker = document.getElementById('blocker');
const modusFelder = [...document.querySelectorAll('input[name=modus]')];
let tab = null;
let host = '';

// Schreibt den Eintrag für die Hauptdomain; beim Ausschalten fliegt auch ein Eintrag
// auf einer Unterseite raus, der den Host noch abdecken würde.
function geaendert(liste, an) {
  const neu = mitSchalter(liste, host, an);
  return an ? neu : neu.filter((eintrag) => !istInListe(host, [eintrag]));
}

async function zeige() {
  const { schutzListe = [], ausnahmen = [], modusWahl: wahl = {}, erkannt = {} } = await chrome.storage.local.get(['schutzListe', 'ausnahmen', 'modusWahl', 'erkannt']);
  const aktiv = !istInListe(host, ausnahmen);
  blocker.checked = aktiv;
  const gewaehlt = wahl[hauptDomain(host)] ?? 'auto';
  for (const feld of modusFelder) {
    feld.checked = feld.value === gewaehlt;
    feld.disabled = !aktiv;
  }
  document.getElementById('modus-jetzt').textContent = `gerade: ${seitenModus({ host, wahl, erkannt, schutzListe, ausnahmen })}`;
}

async function neuLaden() {
  // Erst neu laden, wenn die Regeln stehen, sonst liefe das Neuladen noch unter den alten.
  await chrome.runtime
    .sendMessage({ art: 'regeln-setzen' })
    .catch((fehler) => console.error('Regeln konnten nicht angefragt werden:', fehler));
  await chrome.tabs.reload(tab.id).catch((fehler) => console.error('Neuladen fehlgeschlagen:', fehler));
  await zeige();
}

async function umschalten(schluessel, an) {
  const gespeichert = await chrome.storage.local.get(schluessel);
  await chrome.storage.local.set({ [schluessel]: geaendert(gespeichert[schluessel] ?? [], an) });
  await neuLaden();
}

// Eine Wahl von Hand schlägt die Automatik. „auto" löscht die Wahl und auch die gemerkte Erkennung.
async function waehleModus(wert) {
  const seite = hauptDomain(host);
  const { modusWahl = {}, erkannt = {} } = await chrome.storage.local.get(['modusWahl', 'erkannt']);
  if (wert === 'auto') {
    delete modusWahl[seite];
    delete erkannt[seite];
  } else {
    modusWahl[seite] = wert;
  }
  await chrome.storage.local.set({ modusWahl, erkannt });
  await neuLaden();
}

async function start() {
  [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  let url = null;
  try {
    url = new URL(tab?.url ?? '');
  } catch {}
  if (!url || !/^https?:$/.test(url.protocol)) {
    document.getElementById('nicht-verfuegbar').hidden = false;
    return;
  }
  host = url.hostname;
  document.getElementById('seite').textContent = hauptDomain(host);
  await zeige();
  // Ausnahme an = Blocker aus, darum umgekehrt.
  blocker.addEventListener('change', () => umschalten('ausnahmen', !blocker.checked));
  for (const feld of modusFelder) feld.addEventListener('change', () => waehleModus(feld.value));
  document.getElementById('inhalt').hidden = false;
}

// Hinweis, wenn der Bau über 14 Tage her ist. Läuft nebenher; Fehler bleiben still, die Schalter gehen vor.
async function pruefeAlter() {
  try {
    const antwort = await fetch(chrome.runtime.getURL('stand.json'));
    const { gebaut } = await antwort.json();
    document.getElementById('veraltet').hidden = !updateVeraltet(gebaut, Date.now());
  } catch {}
}

const UPDATE_TEXTE = {
  aktuell: 'alles aktuell',
  neu: 'neue version, lädt neu ...',
  update: 'gerade nicht möglich, versuch es später',
  'kein-helfer': 'noch nicht bereit, kommt mit dem nächsten automatischen update',
};

const updateKnopf = document.getElementById('update');
const updateText = document.getElementById('update-text');
updateKnopf.addEventListener('click', async () => {
  updateKnopf.disabled = true;
  updateText.textContent = 'suche ...';
  const ergebnis = await chrome.runtime.sendMessage({ art: 'update-suchen' }).catch(() => null);
  updateText.textContent = ergebnis ? UPDATE_TEXTE[ergebnis.grund ?? ergebnis.art] : UPDATE_TEXTE.update;
  updateKnopf.disabled = false;
});

function zeigeGesamt(wert = 0) {
  document.getElementById('gesamt').textContent = wert.toLocaleString('de-DE');
}

chrome.storage.local.get('blockiertGesamt').then(({ blockiertGesamt }) => zeigeGesamt(blockiertGesamt));
chrome.storage.onChanged.addListener((aenderungen, bereich) => {
  if (bereich === 'local' && aenderungen.blockiertGesamt) zeigeGesamt(aenderungen.blockiertGesamt.newValue);
});

start();
pruefeAlter();
