// Twitch (MAIN-Welt): holt den Ton zurück, wenn vaft nach der Werbung das Video ersetzt
// und das neue Element ohne Stummschaltung auf Lautstärke 0 stehen bleibt.
(() => {
  if (!window.createVolumeGuard) return;
  const waechter = window.createVolumeGuard();
  setInterval(() => {
    const video = document.querySelector('video');
    const stand = video ? { muted: video.muted, volume: video.volume } : null;
    const aktion = waechter.observe(stand, Date.now());
    if (aktion && video) video.volume = aktion.restoreTo;
  }, 300);
})();
