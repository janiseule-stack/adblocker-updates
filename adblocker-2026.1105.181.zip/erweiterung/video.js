// Werbung im Video (MAIN-Welt), nur im strengen Modus. Eindeutig heißt: ein Video bis 10 Minuten und im selben
// Rahmen eine sichtbare Werbe-Kennung wie „Ad 1 / 1" oder „Skip Ad in 5s". Das Video wird sofort unsichtbar, stumm
// und schnell, damit nichts zu sehen ist. Der Knopf wird gedrückt, sobald er geht. Danach startet der Film.
(() => {
  // Gemessen: Werbevideos laufen bis über 4 Minuten. Filme und Folgen sind länger, die Sicherheit gibt die Kennung.
  const MAX_WERBUNG_S = 600;
  const SCHNELL = 16;
  const TAKT_MS = 250;
  // Nur kurze Beschriftungen, damit ein Satz im Fließtext nie als Kennung zählt.
  const MAX_TEXT = 40;
  // Player beschriften Werbung in der Sprache ihrer Herkunft. Gemessen auf einer Film-Seite: „Реклама“ und
  // „Пропустить“ (Russisch). Ein einzelnes Wort zählt nur, wenn es eindeutig „Werbung“ heißt, nie „Überspringen“ allein.
  const KENNUNG = new RegExp('^(' + [
    'ad\\s+\\d+\\s*(\\/|of)\\s*\\d+', 'skip\\s+ad\\b.*', 'skip\\s+in\\s+\\d+.*', 'advertisement',
    'werbung\\s+(überspringen|in\\s+\\d+).*', 'anzeige\\s+\\d+\\s*(\\/|von)\\s*\\d+', 'überspringen\\s+in\\s+\\d+.*',
    'реклама(\\s+\\d+\\s*(\\/|из)\\s*\\d+)?', 'пропустить\\s+рекламу.*', 'пропустить(\\s+рекламу)?\\s+через\\s+\\d+.*',
    'publicité(\\s+\\d+\\s*(\\/|sur)\\s*\\d+)?', 'passer\\s+(la\\s+pub\\w*|dans\\s+\\d+).*',
    'publicidad', 'anuncio(\\s+\\d+\\s*(\\/|de)\\s*\\d+)?', '(saltar|omitir)\\s+(anuncio|en\\s+\\d+).*',
    'pubblicità', 'salta\\s+(annuncio|tra\\s+\\d+).*',
    'reklama(\\s+\\d+\\s*(\\/|z)\\s*\\d+)?', 'pomiń\\s+(reklamę|za\\s+\\d+).*',
    'reklam', 'reklamı\\s+(geç|atla).*',
  ].join('|') + ')$', 'iu');
  const KNOPF_FERTIG = /^(skip(\s+ad)?|werbung\s+überspringen|überspringen|пропустить(\s+рекламу)?|passer(\s+la\s+pub\w*)?|(saltar|omitir)(\s+anuncio)?|salta(\s+annuncio)?|pomiń(\s+reklamę)?|reklamı\s+(geç|atla)|geç|atla)$/iu;

  let streng = false;
  // Merkt je Video, was vor dem Eingriff galt, und welche Quelle als Werbung erkannt wurde.
  const vorher = new WeakMap();

  function setzeModus(ereignis) {
    try {
      const modus = JSON.parse(String(ereignis.detail)).modus;
      if (typeof modus === 'string') streng = modus === 'streng';
    } catch {
      // Unlesbare Meldung: bleibt, wie es ist.
    }
  }
  document.addEventListener('__adblocker_einstellungen', setzeModus);
  document.addEventListener('__adblocker_modus', () => { streng = true; });
  document.dispatchEvent(new CustomEvent('__adblocker_anfrage'));

  function text(element) {
    return element.textContent.trim().replace(/\s+/g, ' ');
  }

  function sichtbar(element) {
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && element.checkVisibility({ visibilityProperty: true, opacityProperty: true });
  }

  // Alle Elemente, nicht nur div und span: Manche Player bauen ihre Bedienung aus eigenen Elementen (z. B. <pjsdiv>).
  // Es zählt das innerste Element mit diesem Text: Ein sichtbarer Rahmen um eine unsichtbare Beschriftung gilt nicht.
  function findeBeschriftung(muster) {
    if (!document.body) return null;
    for (const element of document.body.querySelectorAll('*')) {
      if (element.matches('script, style, video, svg')) continue;
      const inhalt = text(element);
      if (!inhalt || inhalt.length > MAX_TEXT || !muster.test(inhalt)) continue;
      if ([...element.children].some((kind) => text(kind) === inhalt)) continue;
      if (sichtbar(element)) return element;
    }
    return null;
  }

  function hatKennung() {
    return findeBeschriftung(KENNUNG) !== null;
  }

  function verstecke(video) {
    if (!vorher.has(video)) {
      vorher.set(video, { deckkraft: video.style.opacity, stumm: video.muted, tempo: video.playbackRate, quelle: video.currentSrc });
    }
    video.style.opacity = '0';
    video.muted = true;
    if (video.playbackRate !== SCHNELL) video.playbackRate = SCHNELL;
  }

  function stelleZurueck(video) {
    const stand = vorher.get(video);
    if (!stand) return;
    vorher.delete(video);
    video.style.opacity = stand.deckkraft;
    video.muted = stand.stumm;
    video.playbackRate = stand.tempo;
  }

  function istKurz(video) {
    return Number.isFinite(video.duration) && video.duration > 0 && video.duration <= MAX_WERBUNG_S;
  }

  function drueckeKnopf() {
    const beschriftung = findeBeschriftung(KNOPF_FERTIG);
    // Die Beschriftung steckt oft in einem Knopf. Ohne Knopf (eigene Player-Elemente) wird sie selbst gedrückt.
    const knopf = beschriftung?.closest('button, a, [role="button"]') ?? beschriftung;
    if (knopf && !knopf.disabled) knopf.click();
  }

  function pruefe() {
    const videos = [...document.querySelectorAll('video')];
    if (videos.length === 0) return;
    // Beim Film wird nichts durchsucht, nur solange ein kurzes Video läuft.
    const kurze = streng ? videos.filter(istKurz) : [];
    const kennung = kurze.length > 0 && hatKennung();
    for (const video of videos) {
      const schonErkannt = vorher.get(video)?.quelle === video.currentSrc;
      if (kurze.includes(video) && (kennung || schonErkannt)) verstecke(video);
      else stelleZurueck(video);
    }
    if (videos.some((video) => vorher.has(video))) drueckeKnopf();
  }

  setInterval(pruefe, TAKT_MS);
})();
