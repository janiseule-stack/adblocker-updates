// Hintergrundskript: schließt fremde Tabs, blendet Werbeflächen aus, setzt Ausnahmen.
// Einstellungen werden bei jedem Ereignis neu aus chrome.storage.local gelesen,
// weil Chrome das Skript jederzeit schlafen legt.
import { ausnahmeRegeln, DIENSTE, hauptDomain, istGesperrt, istInListe, istLeererStart, istWegwerfHost, istObersterRahmen, obersteUrl, seitenCss, seitenModus, sollNeuLaden, sollTabSchliessen, twitchSkriptAktiv, updateErgebnis } from './lib/logik.js';

// Zahl der blockierten Anfragen als Zahl am Symbol.
chrome.declarativeNetRequest
  .setExtensionActionOptions({ displayActionCountAsBadgeText: true })
  .catch((fehler) => console.error('Blockzähler konnte nicht eingeschaltet werden:', fehler));

// Gesamtzähler fürs Fenster. Chrome meldet jede getroffene Regel einzeln, aber nur an entpackte
// Erweiterungen. Gesammelt geschrieben, damit nicht jede Anfrage den Speicher anfasst.
let ausnahmenImBau = null;
let ungezaehlt = 0;
let zaehlUhr = null;
let zaehlKette = Promise.resolve();

function schreibeZaehler() {
  zaehlUhr = null;
  const neu = ungezaehlt;
  ungezaehlt = 0;
  zaehlKette = zaehlKette
    .then(async () => {
      const { blockiertGesamt = 0 } = await chrome.storage.local.get('blockiertGesamt');
      await chrome.storage.local.set({ blockiertGesamt: blockiertGesamt + neu });
    })
    .catch((fehler) => console.error('Zähler konnte nicht gespeichert werden:', fehler));
}

chrome.declarativeNetRequest.onRuleMatchedDebug?.addListener(async ({ rule, request }) => {
  if (request.tabId >= 0 && istWegwerfHost(hostVon(request.url))) {
    const tab = await chrome.tabs.get(request.tabId).catch(() => null);
    if (tab) erkenneSeite(tab);
  }
  ausnahmenImBau ??= fetch(chrome.runtime.getURL('stand.json'))
    .then((antwort) => antwort.json())
    .then((stand) => stand.ausnahmen ?? {})
    .catch(() => ({}));
  if (!istGesperrt(rule, await ausnahmenImBau)) return;
  ungezaehlt += 1;
  zaehlUhr ??= setTimeout(schreibeZaehler, 500);
});

const START_SCHUTZLISTE = ['serienstream.to', 's.to', 'aniworld.to', 'bs.to'];

async function einstellungen() {
  const { schutzListe = [], ausnahmen = [], modusWahl: wahl = {}, erkannt = {} } = await chrome.storage.local.get(['schutzListe', 'ausnahmen', 'modusWahl', 'erkannt']);
  return { schutzListe, ausnahmen, wahl, erkannt };
}

let allgemeinesCss = null;
let seitenKarte = null;
let seitenAusnahmen = null;
function ladeRegeldateien() {
  allgemeinesCss ??= fetch(chrome.runtime.getURL('rules/generated/allgemein.css')).then((a) => a.text());
  seitenKarte ??= fetch(chrome.runtime.getURL('rules/generated/seiten.json')).then((a) => a.json());
  seitenAusnahmen ??= fetch(chrome.runtime.getURL('rules/generated/seiten-ausnahmen.json')).then((a) => a.json());
  return Promise.all([allgemeinesCss, seitenKarte, seitenAusnahmen]);
}

// Läufe nacheinander, damit sich zwei Aktualisierungen nicht überholen; die letzte Liste gewinnt.
let regelKette = Promise.resolve();
function setzeAusnahmeRegeln() {
  regelKette = regelKette.then(ersetzeAusnahmeRegeln).catch((fehler) => {
    console.error('Ausnahme-Regeln konnten nicht gesetzt werden:', fehler);
  });
  return regelKette;
}

async function ersetzeAusnahmeRegeln() {
  const { ausnahmen } = await einstellungen();
  const alte = await chrome.declarativeNetRequest.getDynamicRules();
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: alte.map((r) => r.id),
    addRules: ausnahmeRegeln(ausnahmen),
  });
  await setzeTwitchSkript(ausnahmen);
}

// Twitch-Schutz: läuft vor den Skripten der Seite. Nicht fest im Manifest, damit der Schalter
// ihn wirklich abstellen kann. Der Wächter steht vor vaft, weil vaft ihn nicht kennt.
const TWITCH_SKRIPT = {
  id: 'twitch-schutz',
  matches: ['*://*.twitch.tv/*'],
  js: ['twitch/volume-guard.js', 'twitch/lautstaerke.js', 'twitch/vaft.js'],
  runAt: 'document_start',
  allFrames: true,
  world: 'MAIN',
};

async function setzeTwitchSkript(ausnahmen) {
  const vorhanden = await chrome.scripting.getRegisteredContentScripts({ ids: [TWITCH_SKRIPT.id] });
  const soll = twitchSkriptAktiv(ausnahmen);
  if (soll && vorhanden.length === 0) await chrome.scripting.registerContentScripts([TWITCH_SKRIPT]);
  if (!soll && vorhanden.length > 0) await chrome.scripting.unregisterContentScripts({ ids: [TWITCH_SKRIPT.id] });
}

function hostVon(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return '';
  }
}

// Nach einem Tausch des Ordners ignoriert Chrome beim ersten Start geaenderte Regelsaetze.
// Die aktuelle Version wird IMMER zuerst gespeichert, erst danach wird neu geladen:
// So gibt es pro Version nur einen Versuch und keine Schleife.
async function pruefeNeueVersion() {
  try {
    const geladen = chrome.runtime.getManifest().version;
    const { geladeneVersion } = await chrome.storage.local.get('geladeneVersion');
    await chrome.storage.local.set({ geladeneVersion: geladen });
    if (sollNeuLaden({ geladen, gemerkt: geladeneVersion })) chrome.runtime.reload();
  } catch (fehler) {
    console.error('Versionspruefung fehlgeschlagen:', fehler);
  }
}

chrome.runtime.onInstalled.addListener(async (details) => {
  const gespeichert = await chrome.storage.local.get(['schutzListe', 'ausnahmen']);
  const neu = {};
  if (!Array.isArray(gespeichert.schutzListe)) neu.schutzListe = START_SCHUTZLISTE;
  if (!Array.isArray(gespeichert.ausnahmen)) neu.ausnahmen = [];
  if (details?.reason === 'install') neu.geladeneVersion = chrome.runtime.getManifest().version;
  await chrome.storage.local.set(neu);
  await setzeAusnahmeRegeln();
});

chrome.runtime.onStartup.addListener(() => {
  setzeAusnahmeRegeln();
  pruefeNeueVersion();
});

chrome.storage.onChanged.addListener((aenderungen, bereich) => {
  if (bereich === 'local' && aenderungen.ausnahmen) setzeAusnahmeRegeln();
});

// Merkt eine Seite als zwielichtig. Läufe nacheinander, damit sich zwei Anzeichen nicht überschreiben.
// Eine Wahl von Hand und ein abgeschalteter Blocker gehen vor.
let erkennKette = Promise.resolve();
function erkenneSeite(tab) {
  erkennKette = erkennKette
    .then(async () => {
      const host = hostVon(tab.url ?? '');
      if (!host || tab.id === undefined) return;
      const stand = await einstellungen();
      const seite = hauptDomain(host);
      if (stand.wahl[seite] || seitenModus({ host, ...stand }) !== 'normal') return;
      await chrome.storage.local.set({ erkannt: { ...stand.erkannt, [seite]: true } });
      await chrome.tabs.sendMessage(tab.id, { art: 'streng-an' }).catch(() => {});
    })
    .catch((fehler) => console.error('Seite nicht gemerkt:', fehler));
}

// Lang genug für das Kontextmenü „In neuem Tab öffnen".
const LINK_GUELTIG_MS = 60000;

// Nur Klicks aus der Seite selbst geben ein Ziel frei. Ein Klick in einem fremden Rahmen kann ein Werbebanner
// sein oder „Auf YouTube ansehen". Der Tab bleibt zu, die Seite bietet ihn aber an.
async function merkeLinkKlick(nachricht, absender) {
  const tabId = absender.tab?.id;
  const seite = hostVon(absender.tab?.url ?? '');
  const rahmen = hostVon(absender.url ?? '');
  const ziel = hostVon(nachricht.ziel ?? '');
  if (tabId === undefined || !seite || !ziel) return;
  const { linkKlicks = {} } = await chrome.storage.session.get('linkKlicks');
  linkKlicks[tabId] = { host: ziel, zeit: Date.now(), fremd: hauptDomain(seite) !== hauptDomain(rahmen) };
  await chrome.storage.session.set({ linkKlicks });
}

// Im strengen Modus: Ein fremder Rahmen leitet nach einem Klick die ganze Seite um. In der Seite lässt sich das
// nicht verhindern, Chrome meldet es dort nicht. Also zurück, sobald der Tab drüben ist. Rahmen von Anmelde- und
// Zahlungsdiensten dürfen das, dort ist es gewollt. Im Modus normal bleibt es erlaubt, wegen Bezahlvorgängen.
const RAHMEN_KLICK_GILT_MS = 5000;
// Das Hintergrundskript kann schlafen: Der Seitenwechsel kommt dann vor der Meldung des Klicks an.
const RAHMEN_KLICK_WARTEN_MS = 700;

// Die Verbindung selbst hält das Hintergrundskript wach, zu tun ist nichts.
chrome.runtime.onConnect.addListener((leitung) => {
  if (leitung.name === 'wach') leitung.onMessage.addListener(() => {});
});

async function merkeRahmenKlick(nachricht, absender) {
  const tabId = absender.tab?.id;
  const seite = hostVon(nachricht.oben ?? '') || hostVon(absender.tab?.url ?? '');
  const rahmen = hostVon(absender.url ?? '');
  if (tabId === undefined || !seite || !rahmen) return;
  if (hauptDomain(seite) === hauptDomain(rahmen) || istInListe(rahmen, DIENSTE)) return;
  const { rahmenKlicks = {} } = await chrome.storage.session.get('rahmenKlicks');
  rahmenKlicks[tabId] = { seite, zeit: Date.now() };
  await chrome.storage.session.set({ rahmenKlicks });
}

chrome.webNavigation.onCommitted.addListener(async (details) => {
  if (details.frameId !== 0 || !/^https?:/.test(details.url)) return;
  if (details.transitionQualifiers?.includes('forward_back')) return;
  await new Promise((fertig) => setTimeout(fertig, RAHMEN_KLICK_WARTEN_MS));
  const { rahmenKlicks = {} } = await chrome.storage.session.get('rahmenKlicks');
  const klick = rahmenKlicks[details.tabId];
  if (!klick || Date.now() - klick.zeit > RAHMEN_KLICK_GILT_MS) return;
  const ziel = hostVon(details.url);
  if (hauptDomain(ziel) === hauptDomain(klick.seite) || istInListe(ziel, DIENSTE)) return;
  delete rahmenKlicks[details.tabId];
  await chrome.storage.session.set({ rahmenKlicks });
  const stand = await einstellungen();
  if (seitenModus({ host: klick.seite, ...stand }) !== 'streng') return;
  await chrome.tabs.goBack(details.tabId).catch(() => {});
});

// Prüft einen Tab, den eine Seite geöffnet hat, und schließt ihn, wenn er zu einer fremden Adresse führt.
async function pruefeNeuenTab({ quellTabId, tabId, zielUrl, rahmenUrl }) {
  const quelle = await chrome.tabs.get(quellTabId).catch(() => null);
  if (!quelle) return;
  // Die Meldung des Link-Klicks kann kurz nach dem neuen Tab ankommen.
  await new Promise((fertig) => setTimeout(fertig, 200));
  const stand = await einstellungen();
  const { linkKlicks = {} } = await chrome.storage.session.get('linkKlicks');
  const klick = linkKlicks[quellTabId];
  const klickGilt = klick && Date.now() - klick.zeit < LINK_GUELTIG_MS;
  const modus = seitenModus({ host: hostVon(quelle.url ?? ''), ...stand });
  const schliessen = sollTabSchliessen({
    quellUrl: quelle.url ?? '',
    zielUrl,
    modus,
    linkZiel: klickGilt && !klick.fremd ? klick.host : undefined,
    rahmenUrl,
  });
  if (!schliessen) return;
  await chrome.tabs.remove(tabId).catch(() => {});
  await chrome.tabs.update(quellTabId, { active: true }).catch(() => {});
  if (modus === 'normal' && klickGilt && klick.fremd && hostVon(zielUrl) === klick.host) {
    await chrome.tabs.sendMessage(quellTabId, { art: 'fenster-angebot', ziel: zielUrl }, { frameId: 0 }).catch(() => {});
  }
}

chrome.webNavigation.onCreatedNavigationTarget.addListener(async (details) => {
  const rahmen = await chrome.webNavigation
    .getFrame({ tabId: details.sourceTabId, frameId: details.sourceFrameId })
    .catch(() => null);
  await pruefeNeuenTab({ quellTabId: details.sourceTabId, tabId: details.tabId, zielUrl: details.url, rahmenUrl: rahmen?.url });
});

// Leer geöffnete Tabs und Fenster: Chrome meldet für sie kein Navigationsziel, wenn sie erst danach
// weiterspringen. Darum gemerkt und beim ersten Sprung auf eine echte Adresse geprüft.
// Im Sitzungsspeicher, weil das Hintergrundskript dazwischen schlafen kann.
const LEER_GILT_MS = 60000;

// Alle Zugriffe nacheinander: Springt das Fenster sofort weiter, muss das Merken vorher fertig sein.
let leerKette = Promise.resolve();
function mitLeerenTabs(arbeit) {
  const lauf = leerKette.then(async () => {
    const { leereTabs = {} } = await chrome.storage.session.get('leereTabs');
    const ergebnis = arbeit(leereTabs);
    await chrome.storage.session.set({ leereTabs });
    return ergebnis;
  });
  leerKette = lauf.catch((fehler) => console.error('Leere Tabs nicht gespeichert:', fehler));
  return lauf;
}

chrome.tabs.onCreated.addListener((tab) => {
  if (!istLeererStart(tab)) return;
  mitLeerenTabs((leereTabs) => {
    leereTabs[tab.id] = { quelle: tab.openerTabId, zeit: Date.now() };
  });
});

// Nur Sprünge, die die Seite auslöst. Eine eingetippte Adresse oder ein Lesezeichen ist der Nutzer selbst.
const SEITEN_SPRUENGE = ['link', 'form_submit'];

chrome.webNavigation.onCommitted.addListener(async (details) => {
  if (details.frameId !== 0 || !/^https?:/i.test(details.url)) return;
  const eintrag = await mitLeerenTabs((leereTabs) => {
    const gefunden = leereTabs[details.tabId];
    delete leereTabs[details.tabId];
    return gefunden;
  });
  if (!eintrag || Date.now() - eintrag.zeit > LEER_GILT_MS) return;
  if (!SEITEN_SPRUENGE.includes(details.transitionType)) return;
  await pruefeNeuenTab({ quellTabId: eintrag.quelle, tabId: details.tabId, zielUrl: details.url });
});

chrome.tabs.onRemoved.addListener((tabId) => {
  mitLeerenTabs((leereTabs) => {
    delete leereTabs[tabId];
  });
});

chrome.webNavigation.onCommitted.addListener(async (details) => {
  if (!/^https?:/.test(details.url)) return;
  const hauptframe = istObersterRahmen(details);
  let topHost = hostVon(details.url);
  if (!hauptframe) {
    const tab = await chrome.tabs.get(details.tabId).catch(() => null);
    topHost = hostVon(tab?.url ?? '');
  }
  if (!topHost) return;
  const { ausnahmen } = await einstellungen();
  if (istInListe(topHost, ausnahmen)) return;
  const [allgemein, karte, seitenAusnahmeKarte] = await ladeRegeldateien();
  const teile = [];
  if (hauptframe) teile.push(allgemein);
  teile.push(seitenCss(topHost, karte, seitenAusnahmeKarte));
  const css = teile.filter(Boolean).join('\n');
  if (!css) return;
  // Auf manchen Seiten (z. B. Chrome Web Store, Fehlerseiten) ist Einfügen unmöglich, das ist normal.
  await chrome.scripting
    .insertCSS({ target: { tabId: details.tabId, frameIds: [details.frameId] }, css, origin: 'USER' })
    .catch(() => {});
});

// Update-Knopf: Der Helfer auf dem PC holt die neue Version. Danach merkt sich die Erweiterung sie
// und lädt sich neu, damit sie beim nächsten Browser-Start nicht noch einmal neu lädt.
async function sucheUpdate() {
  const antwort = await chrome.runtime.sendNativeMessage('com.adblocker.update', { art: 'suchen' }).catch(() => null);
  const ergebnis = updateErgebnis({ geladen: chrome.runtime.getManifest().version, antwort });
  if (ergebnis.art === 'neu') {
    await chrome.storage.local.set({ geladeneVersion: ergebnis.version });
    setTimeout(() => chrome.runtime.reload(), 800);
  }
  return ergebnis;
}

// Antworten für fenster.js und bruecke.js. Synchron registriert, die Antwort kommt asynchron (return true).
chrome.runtime.onMessage.addListener((nachricht, absender, antworte) => {
  if (nachricht?.art === 'update-suchen') {
    // Nur aus dem eigenen Fenster, nie aus einem Skript in einer Webseite.
    if (absender.tab && absender.url !== chrome.runtime.getURL('fenster.html')) return false;
    sucheUpdate().then(antworte);
    return true;
  }
  if (nachricht?.art === 'regeln-setzen') {
    // Auch nach einem Fehler antworten (er ist in setzeAusnahmeRegeln protokolliert): Das Fenster lädt dann trotzdem neu.
    setzeAusnahmeRegeln().then(() => antworte({ fertig: true }));
    return true;
  }
  if (nachricht?.art === 'fenster-erlauben') {
    const ziel = String(nachricht.ziel ?? '');
    if (absender.tab && /^https?:/i.test(ziel)) {
      chrome.tabs
        .create({ url: ziel, openerTabId: absender.tab.id, index: absender.tab.index + 1 })
        .catch((fehler) => console.error('Fenster nicht geöffnet:', fehler));
    }
    return false;
  }
  if (nachricht?.art === 'rahmen-klick') {
    merkeRahmenKlick(nachricht, absender).catch((fehler) => console.error('Rahmen-Klick nicht gemerkt:', fehler));
    return false;
  }
  if (nachricht?.art === 'anzeichen') {
    if (absender.tab) erkenneSeite(absender.tab);
    return false;
  }
  if (nachricht?.art === 'link-klick') {
    merkeLinkKlick(nachricht, absender).catch((fehler) => console.error('Link-Klick nicht gemerkt:', fehler));
    return false;
  }
  if (nachricht?.art !== 'zustand') return false;
  const host = hostVon(obersteUrl(nachricht, absender));
  einstellungen().then((stand) => {
    const blocker = host !== '' && !istInListe(host, stand.ausnahmen);
    antworte({ blocker, modus: host ? seitenModus({ host, ...stand }) : 'aus', seite: host ? hauptDomain(host) : '' });
  });
  return true;
});
