// Brücke (ISOLATED): holt den Zustand der Seite vom Hintergrundskript und reicht ihn
// als JSON-Text an die Seitenumgebung weiter (schutz.js und das YouTube-Skript lesen ihn dort).
(() => {
  let zustand = null;
  // Schlüssel von schutz.js, das vor jedem Skript der Seite läuft. Nur Meldungen mit ihm zählen dort.
  let schluessel = '';

  // Auf strengen Seiten bleibt das Hintergrundskript wach. Schläft es, geht die Meldung eines Klicks im
  // fremden Rahmen verloren, weil der Rahmen beim Umleiten verschwindet (gemessen).
  const WACH_TAKT_MS = 20000;
  let wachUhr = null;

  function halteWach() {
    if (window.top !== window || wachUhr !== null) return;
    let leitung = null;
    const verbinde = () => {
      try {
        leitung = chrome.runtime.connect({ name: 'wach' });
        leitung.onDisconnect.addListener(() => setTimeout(verbinde, 100));
      } catch {
        // Die Erweiterung wurde neu geladen, diese Seite hat keine Verbindung mehr.
        clearInterval(wachUhr);
      }
    };
    verbinde();
    wachUhr = setInterval(() => {
      try {
        leitung.postMessage('wach');
      } catch {
        // Die Verbindung baut sich gerade neu auf.
      }
    }, WACH_TAKT_MS);
  }

  // Die Meldung mit Schlüssel ist nur für schutz.js, das sie anhält. Die offene ist für das Video und YouTube.
  function senden() {
    if (zustand === null) return;
    if (schluessel) document.dispatchEvent(new CustomEvent('__adblocker_schutz', { detail: JSON.stringify({ ...zustand, schluessel }) }));
    document.dispatchEvent(new CustomEvent('__adblocker_einstellungen', { detail: JSON.stringify(zustand) }));
  }

  document.addEventListener('__adblocker_anfrage', (ereignis) => {
    if (!schluessel && typeof ereignis.detail === 'string') schluessel = ereignis.detail;
    senden();
  });

  // Anzeichen kommen aus schutz.js. Eine Fälschung der Seite könnte nur den Schutz verschärfen.
  document.addEventListener('__adblocker_anzeichen', () => {
    chrome.runtime.sendMessage({ art: 'anzeichen' }).catch(() => {});
  });

  // Geöffnet wird nur nach einem echten Klick auf den Hinweis, das prüft hinweis.js. Das Fenster
  // öffnet das Hintergrundskript, die Seite bekommt keinen Zugriff darauf.
  function bieteFensterAn(ziel) {
    if (typeof ziel !== 'string' || !/^https?:/i.test(ziel)) return;
    globalThis.adblockerHinweis({
      text: 'Fenster blockiert –',
      knopf: 'trotzdem öffnen?',
      dauer: 8000,
      beiKlick: () => chrome.runtime.sendMessage({ art: 'fenster-erlauben', ziel }).catch(() => {}),
    });
  }

  document.addEventListener('__adblocker_blockiert', (ereignis) => bieteFensterAn(ereignis.detail));

  chrome.runtime.onMessage.addListener((nachricht) => {
    if (nachricht?.art === 'fenster-angebot') {
      bieteFensterAn(nachricht.ziel);
      return;
    }
    if (nachricht?.art !== 'streng-an') return;
    document.dispatchEvent(new CustomEvent('__adblocker_modus', { detail: 'streng' }));
    if (window.top === window) globalThis.adblockerHinweis({ text: '> streng an' });
    halteWach();
  });

  // Echter Link-Klick: Nur hier sieht man sicher, dass ein Mensch geklickt hat, die Seite kann das nicht vortäuschen.
  // Maustaste gedrückt statt Klick, damit auch die mittlere Taste und das Kontextmenü zählen.
  function linkAn(pfad) {
    const link = pfad.find((element) => element instanceof Element && element.matches('a[href]'));
    if (!link || !/^https?:/i.test(link.href)) return null;
    const rect = link.getBoundingClientRect();
    // Eine riesige Fläche ohne Inhalt ist eine Klickfläche für Werbung, kein Link.
    const riesig = rect.width * rect.height > (innerWidth * innerHeight) / 2;
    if (riesig && !link.querySelector('img, video, svg') && link.textContent.trim() === '') return null;
    return link;
  }

  function merkeLink(link) {
    if (link) chrome.runtime.sendMessage({ art: 'link-klick', ziel: link.href }).catch(() => {});
  }

  window.addEventListener('pointerdown', (ereignis) => {
    if (!ereignis.isTrusted) return;
    merkeLink(linkAn(ereignis.composedPath()));
    // Leitet ein Rahmen die ganze Seite um, sieht die Seite das nicht. Darum merkt es sich der Hintergrund.
    // Die oberste Seite gleich mitschicken: Wacht der Hintergrund erst auf, kann der Tab schon woanders sein.
    if (window.top !== window) {
      const herkunft = location.ancestorOrigins;
      chrome.runtime.sendMessage({ art: 'rahmen-klick', oben: herkunft[herkunft.length - 1] ?? '' }).catch(() => {});
    }
  }, true);
  window.addEventListener('keydown', (ereignis) => {
    if (ereignis.isTrusted && ereignis.key === 'Enter') merkeLink(linkAn(ereignis.composedPath()));
  }, true);

  chrome.runtime
    .sendMessage({ art: 'zustand', oberster: window.top === window })
    .then((antwort) => {
      if (!antwort || typeof antwort !== 'object') return;
      zustand = {
        blocker: antwort.blocker === true,
        modus: typeof antwort.modus === 'string' ? antwort.modus : 'normal',
        seite: typeof antwort.seite === 'string' ? antwort.seite : '',
      };
      senden();
      if (zustand.modus === 'streng') halteWach();
    })
    .catch(() => {});
})();
