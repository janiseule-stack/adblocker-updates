# Holt die neueste geprueft gebaute Version des Adblockers und tauscht den Ordner
# "erweiterung" nur als Ganzes aus. Zeigt nie ein Fenster oder eine Rueckfrage.
# Exit 0: aktualisiert oder nichts zu tun. Exit 1: Fehler (alter Stand bleibt aktiv).
param(
    [string]$QuellUrl = 'https://raw.githubusercontent.com/janiseule-stack/adblocker-updates/versionen',
    [string]$Basis = (Join-Path $env:LOCALAPPDATA 'Adblocker'),
    # Nur fuer Tests: Dort landet der Registry-Eintrag fuer den Update-Knopf.
    [string]$RegistryWurzel = ''
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = 'Tls12'

$LogDatei = Join-Path $Basis 'aktualisiere.log'

function Schreibe-Log([string]$Text) {
    try {
        if (-not (Test-Path -LiteralPath $Basis)) { New-Item -ItemType Directory -Path $Basis -Force | Out-Null }
        $zeile = '{0} {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Text
        Add-Content -LiteralPath $LogDatei -Value $zeile -Encoding ASCII
        $alle = @(Get-Content -LiteralPath $LogDatei)
        if ($alle.Count -gt 200) {
            Set-Content -LiteralPath $LogDatei -Value ($alle | Select-Object -Last 100) -Encoding ASCII
        }
    } catch { }
}

function Loesche-Weg([string]$Pfad) {
    if (Test-Path -LiteralPath $Pfad) {
        try { Remove-Item -LiteralPath $Pfad -Recurse -Force -ErrorAction Stop }
        catch { Schreibe-Log ('Konnte nicht loeschen, wird beim naechsten Lauf versucht: ' + $Pfad) }
    }
}

function Lies-Json([string]$Pfad) {
    Get-Content -LiteralPath $Pfad -Raw -Encoding UTF8 | ConvertFrom-Json
}

function Schreibe-Wenn-Anders([string]$Pfad, [string]$Text) {
    $alt = $null
    if (Test-Path -LiteralPath $Pfad) { $alt = [IO.File]::ReadAllText($Pfad) }
    if ($alt -cne $Text) { [IO.File]::WriteAllText($Pfad, $Text, (New-Object System.Text.UTF8Encoding($false))) }
}

# Der Knopf-Helfer nimmt vom Browser nur das Signal an und startet den normalen Update-Lauf.
# Der Inhalt der Nachricht wird nie verwendet. Es wird nur das Signal gelesen.
$KnopfSkript = @'
param([string]$QuellUrl = '')
function Antworte($Werte) {
    $daten = [Text.Encoding]::UTF8.GetBytes(($Werte | ConvertTo-Json -Compress))
    $aus = [Console]::OpenStandardOutput()
    $aus.Write([BitConverter]::GetBytes([int]$daten.Length), 0, 4)
    $aus.Write($daten, 0, $daten.Length)
    $aus.Flush()
}
$basis = Split-Path -Parent $PSScriptRoot
$ok = $false
try {
    $kopf = New-Object byte[] 4
    [void][Console]::OpenStandardInput().Read($kopf, 0, 4)
    $helferArgs = @('-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', (Join-Path $basis 'aktualisiere.ps1'), '-Basis', $basis)
    if ($QuellUrl) { $helferArgs += @('-QuellUrl', $QuellUrl) }
    & powershell.exe @helferArgs 2>$null | Out-Null
    $ok = ($LASTEXITCODE -eq 0)
} catch { $ok = $false }
$version = $null
try { $version = [string](Get-Content -LiteralPath (Join-Path $basis 'erweiterung\stand.json') -Raw -Encoding UTF8 | ConvertFrom-Json).version } catch { }
Antworte ([ordered]@{ ok = $ok; version = $version })
exit 0
'@

# Traegt den Knopf-Helfer ein. Bestehende Installationen bekommen ihn so ohne Stick.
function Richte-Knopf-Ein {
    $wurzel = $RegistryWurzel
    if (-not $wurzel) {
        $standard = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'Adblocker')).TrimEnd('\')
        if ([IO.Path]::GetFullPath($Basis).TrimEnd('\') -ine $standard) { return }
        # Gemessen: Chrome und Opera GX lesen beide diesen Pfad.
        $wurzel = 'HKCU:\Software\Google\Chrome\NativeMessagingHosts'
    }
    $ordner = Join-Path $Basis 'knopf'
    if (-not (Test-Path -LiteralPath $ordner)) { New-Item -ItemType Directory -Path $ordner -Force | Out-Null }

    # Kennung wie im Browser: aus dem Pfad des Ordners berechnet.
    $pfad = [IO.Path]::GetFullPath((Join-Path $Basis 'erweiterung')).TrimEnd('\')
    if ($pfad -cmatch '^[a-z]:') { $pfad = $pfad.Substring(0, 1).ToUpperInvariant() + $pfad.Substring(1) }
    $sha = [Security.Cryptography.SHA256]::Create()
    $hex = ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::Unicode.GetBytes($pfad))) -replace '-', '').Substring(0, 32)
    $sha.Dispose()
    $kennung = -join ($hex.ToCharArray() | ForEach-Object { [char](97 + [Convert]::ToInt32([string]$_, 16)) })

    $quelle = ''
    if ($script:QuellUrlGesetzt) { $quelle = ' -QuellUrl "' + $QuellUrl + '"' }
    $bat = "@echo off`r`npowershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File `"%~dp0knopf.ps1`"$quelle`r`n"
    $manifest = [ordered]@{
        name = 'com.adblocker.update'
        description = 'ADBLOCKER Update-Knopf'
        path = 'knopf.bat'
        type = 'stdio'
        allowed_origins = @("chrome-extension://$kennung/")
    } | ConvertTo-Json
    $manifestDatei = Join-Path $ordner 'com.adblocker.update.json'
    Schreibe-Wenn-Anders (Join-Path $ordner 'knopf.ps1') $KnopfSkript
    Schreibe-Wenn-Anders (Join-Path $ordner 'knopf.bat') $bat
    Schreibe-Wenn-Anders $manifestDatei $manifest

    $schluessel = Join-Path $wurzel 'com.adblocker.update'
    if (-not (Test-Path -LiteralPath $schluessel)) { New-Item -Path $schluessel -Force | Out-Null }
    Set-Item -LiteralPath $schluessel -Value $manifestDatei
}

$script:QuellUrlGesetzt = $PSBoundParameters.ContainsKey('QuellUrl')

# Mutex-Name: pro Basis, damit nur Laeufe auf derselben Installation sich sperren.
# Dieser Block steht gleich in aktualisiere.ps1 und einrichten.ps1 (ein Test prueft das).
$basisSchluessel = [IO.Path]::GetFullPath($Basis).TrimEnd('\').ToLowerInvariant()
$sha = [Security.Cryptography.SHA256]::Create()
$MutexName = 'Local\AdblockerAktualisierung-' + (([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($basisSchluessel))) -replace '-', '').Substring(0, 16))
$sha.Dispose()
# Ende Mutex-Name
$mutex = New-Object System.Threading.Mutex($false, $MutexName)
$hatMutex = $false
$exitCode = 0
try {
    try { $hatMutex = $mutex.WaitOne(0) } catch [System.Threading.AbandonedMutexException] { $hatMutex = $true }
    if (-not $hatMutex) {
        Schreibe-Log 'Anderer Lauf aktiv (Mutex belegt), dieser Lauf endet ohne Aenderung'
        exit 0
    }

    $erweiterung = Join-Path $Basis 'erweiterung'
    $alt = Join-Path $Basis 'alt'
    $neu = Join-Path $Basis 'neu'
    $neuZip = Join-Path $Basis 'neu.zip'
    $helferZiel = Join-Path $Basis 'aktualisiere.ps1'

    try {
        if (-not (Test-Path -LiteralPath $Basis)) { New-Item -ItemType Directory -Path $Basis -Force | Out-Null }

        # Scheitert der Knopf-Helfer, laeuft das Update trotzdem.
        try { Richte-Knopf-Ein } catch { Schreibe-Log ('Knopf-Helfer nicht eingerichtet: ' + $_.Exception.Message) }

        # Reste eines abgebrochenen Laufs: fehlt erweiterung, kommt alt zuerst zurueck.
        if ((-not (Test-Path -LiteralPath $erweiterung)) -and (Test-Path -LiteralPath $alt)) {
            [IO.Directory]::Move($alt, $erweiterung)
            Schreibe-Log 'alt wurde als erweiterung wiederhergestellt'
        }
        Loesche-Weg $alt
        Loesche-Weg $neu
        Loesche-Weg $neuZip
        # Bleiben Reste stehen, wuerde Expand-Archive hineinentpacken und Altes mit Neuem mischen.
        if ((Test-Path -LiteralPath $neu) -or (Test-Path -LiteralPath $neuZip)) {
            throw 'Reste von neu oder neu.zip lassen sich nicht loeschen, Lauf abgebrochen'
        }

        $antwort = Invoke-WebRequest -Uri ($QuellUrl.TrimEnd('/') + '/aktuell.json') -UseBasicParsing -TimeoutSec 30
        $text = $antwort.Content
        if ($text -is [byte[]]) { $text = [Text.Encoding]::UTF8.GetString($text) }
        $aktuell = ($text.TrimStart([char]0xFEFF)) | ConvertFrom-Json

        if ([string]$aktuell.version -notmatch '^\d+\.\d+\.\d+$') { throw 'aktuell.json: version ist ungueltig' }
        if ([string]$aktuell.datei -cnotmatch '^[A-Za-z0-9._-]+\.zip$') { throw 'aktuell.json: datei ist ungueltig' }
        if ([string]$aktuell.sha256 -notmatch '^[0-9A-Fa-f]{64}$') { throw 'aktuell.json: sha256 ist ungueltig' }
        $version = [string]$aktuell.version

        $installiert = $null
        $standDatei = Join-Path $erweiterung 'stand.json'
        if (Test-Path -LiteralPath $standDatei) {
            try { $installiert = [string](Lies-Json $standDatei).version } catch { $installiert = $null }
        }
        if ($installiert -eq $version) {
            Schreibe-Log ('Nichts zu tun, Version ' + $version + ' ist aktuell')
            exit 0
        }

        Schreibe-Log ('Lade Version ' + $version + ' (installiert: ' + $installiert + ')')
        Invoke-WebRequest -Uri ($QuellUrl.TrimEnd('/') + '/' + $aktuell.datei) -UseBasicParsing -TimeoutSec 30 -OutFile $neuZip

        $summe = (Get-FileHash -LiteralPath $neuZip -Algorithm SHA256).Hash
        if ($summe -ne ([string]$aktuell.sha256).ToUpperInvariant()) { throw 'Pruefsumme stimmt nicht, Paket wird verworfen' }

        Expand-Archive -LiteralPath $neuZip -DestinationPath $neu -Force

        $neuErweiterung = Join-Path $neu 'erweiterung'
        $manifestVersion = [string](Lies-Json (Join-Path $neuErweiterung 'manifest.json')).version
        $standVersion = [string](Lies-Json (Join-Path $neuErweiterung 'stand.json')).version
        if ($manifestVersion -ne $version) { throw ('Version im Manifest (' + $manifestVersion + ') passt nicht zu ' + $version) }
        if ($standVersion -ne $version) { throw ('Version in stand.json (' + $standVersion + ') passt nicht zu ' + $version) }

        # Tausch: nur ganze Ordner umbenennen. Scheitert der erste Schritt (z. B. Sperre), ist nichts veraendert.
        $hatAlt = Test-Path -LiteralPath $erweiterung
        if ($hatAlt) { [IO.Directory]::Move($erweiterung, $alt) }
        try {
            [IO.Directory]::Move($neuErweiterung, $erweiterung)
        } catch {
            if ($hatAlt) { [IO.Directory]::Move($alt, $erweiterung) }
            throw
        }
        Schreibe-Log ('Version ' + $version + ' eingespielt')

        # Neuen Helfer nur uebernehmen, wenn er sich fehlerfrei lesen laesst.
        $neuerHelfer = Join-Path $neu 'helfer\aktualisiere.ps1'
        if (Test-Path -LiteralPath $neuerHelfer) {
            try {
                $temp = $helferZiel + '.tmp'
                Copy-Item -LiteralPath $neuerHelfer -Destination $temp -Force
                $tokens = $null; $fehler = $null
                [void][Management.Automation.Language.Parser]::ParseFile($temp, [ref]$tokens, [ref]$fehler)
                if ($fehler.Count -gt 0) { throw 'neuer Helfer hat Syntaxfehler' }
                if (Test-Path -LiteralPath $helferZiel) {
                    [IO.File]::Replace($temp, $helferZiel, [NullString]::Value)
                } else {
                    [IO.File]::Move($temp, $helferZiel)
                }
            } catch {
                Schreibe-Log ('Helfer nicht ersetzt: ' + $_.Exception.Message)
                Loesche-Weg ($helferZiel + '.tmp')
            }
        }
    } catch {
        Schreibe-Log ('FEHLER: ' + $_.Exception.Message)
        $exitCode = 1
    }

    # Aufraeumen; Scheitern zaehlt hier nicht als Fehler des Updates.
    # alt ist ggf. die einzige funktionierende Kopie: nur loeschen, wenn erweiterung existiert.
    if (Test-Path -LiteralPath $erweiterung) { Loesche-Weg $alt }
    Loesche-Weg $neu
    Loesche-Weg $neuZip
} finally {
    if ($hatMutex) { $mutex.ReleaseMutex() }
    $mutex.Dispose()
}
exit $exitCode
